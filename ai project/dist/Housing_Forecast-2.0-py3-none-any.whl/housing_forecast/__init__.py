from .predict import run_model

run_model()
