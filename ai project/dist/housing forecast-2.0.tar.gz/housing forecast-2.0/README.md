# Housing Forecast Package

Personal group work project for a personal project.

## Installation

You can install this package using pip:

```bash
pip install Housing_Forecast
